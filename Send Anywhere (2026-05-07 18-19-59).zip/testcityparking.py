import cv2

import time

import os

import requests

import RPi.GPIO as GPIO

from PIL import Image, ImageDraw, ImageFont

from luma.core.interface.serial import spi

from luma.lcd.device import st7735



# ================= CONFIGURATION =================

# GPIO Pins

TRIG_CEILING = 22  # Sensor 1

ECHO_CEILING = 27

TRIG_CAMERA = 23   # Sensor 2 (at camera)

ECHO_CAMERA = 24

SERVO_PIN = 18     # Servo control pin



# API Endpoints

QR_API_URL = "https://api.qrserver.com/v1/read-qr-code/"

VERIFY_URL = "https://smart-parking-backend-u47b.onrender.com/api/parking/verify"



# Thresholds

PHONE_DISTANCE_THRESHOLD = 10  # cm

CEILING_HEIGHT = 200           # cm



# ================= GPIO SETUP =================

GPIO.setmode(GPIO.BCM)

GPIO.setup([TRIG_CEILING, TRIG_CAMERA], GPIO.OUT)

GPIO.setup([ECHO_CEILING, ECHO_CAMERA], GPIO.IN)

GPIO.setup(SERVO_PIN, GPIO.OUT)



# Servo PWM Setup (50Hz)

pwm = GPIO.PWM(SERVO_PIN, 50)

pwm.start(0)



# ================= LCD & CAMERA SETUP =================

serial = spi(port=0, device=0, gpio_DC=25, gpio_RST=26) # Updated RST to 26

device = st7735(serial, width=128, height=128, rotate=0)

cap = cv2.VideoCapture(0)



try:

    font = ImageFont.truetype("DejaVuSans-Bold.ttf", 14)

except:

    font = None



# ================= HELPER FUNCTIONS =================



def set_servo_angle(angle):

    # Mapping 0-180 degrees to 2-12% duty cycle

    duty = angle / 18 + 2

    GPIO.output(SERVO_PIN, True)

    pwm.ChangeDutyCycle(duty)

    time.sleep(1)

    pwm.ChangeDutyCycle(0) # Stop jittering



def get_distance(trig, echo):

    GPIO.output(trig, False)

    time.sleep(0.01)

    GPIO.output(trig, True)

    time.sleep(0.00001)

    GPIO.output(trig, False)

    

    pulse_start = time.time()

    pulse_end = time.time()



    while GPIO.input(echo) == 0:

        pulse_start = time.time()

    while GPIO.input(echo) == 1:

        pulse_end = time.time()



    duration = pulse_end - pulse_start

    return round(duration * 17150, 2)



def show_message(text, frame=None):

    if frame is not None:

        img = Image.fromarray(frame)

    else:

        img = Image.new("RGB", (128, 128), "black")

    draw = ImageDraw.Draw(img)

    if font:

        draw.text((10, 50), text, fill="red", font=font)

    device.display(img)



def get_vehicle_type(dist):

    vehicle_height = CEILING_HEIGHT - dist

    if vehicle_height < 50: return "bike"

    if vehicle_height < 150: return "car"

    return "bus"



# Ensure gate is closed at start

set_servo_angle(0)



# ================= MAIN LOGIC =================

try:

    print("System Running...")

    while True:

        dist_ceiling = get_distance(TRIG_CEILING, ECHO_CEILING)

        

        if dist_ceiling < (CEILING_HEIGHT - 20):

            v_type = get_vehicle_type(dist_ceiling)

            

            # Show Welcome (5s)

            start_welcome = time.time()

            while time.time() - start_welcome < 5:

                show_message(f"WELCOME\n{v_type.upper()}")

            

            qr_data = None

            while qr_data is None:

                ret, frame = cap.read()

                if not ret: break

                

                frame_lcd = cv2.resize(frame, (128, 128))

                frame_lcd = cv2.cvtColor(frame_lcd, cv2.COLOR_BGR2RGB)

                

                dist_phone = get_distance(TRIG_CAMERA, ECHO_CAMERA)

                

                if dist_phone <= PHONE_DISTANCE_THRESHOLD:

                    for i in range(5, 0, -1):

                        show_message(f"Capture in: {i}", frame_lcd)

                        time.sleep(1)

                    

                    cv2.imwrite("temp_qr.jpg", frame)

                    show_message("Decoding QR...")

                    

                    try:

                        with open("temp_qr.jpg", 'rb') as f:

                            response = requests.post(QR_API_URL, files={'file': f})

                            data = response.json()

                            qr_data = data[0]['symbol'][0]['data']

                    except:

                        show_message("QR FAILED\nTry Again")

                        time.sleep(2)

                        break # Go back to scanning

                else:

                    show_message("Hold QR\nto Camera", frame_lcd)



            if qr_data:

                show_message("Verifying...")

                try:

                    payload = {"oneTimeKey": qr_data, "vehicleType": v_type}

                    res = requests.get(VERIFY_URL, params=payload)

                    

                    if "ENTRY_OK" in res.text or "EXIT_OK" in res.text:

                        show_message("OK! OPENING")

                        set_servo_angle(90) # Open Gate

                        time.sleep(5)       # Wait 5 seconds

                        show_message("CLOSING GATE")

                        set_servo_angle(0)  # Close Gate

                    else:

                        show_message("DECLINED\nTry Again")

                        time.sleep(3)

                except:

                    show_message("Server Error")

                    time.sleep(3)

        

        time.sleep(0.5)



except KeyboardInterrupt:

    print("Stopped")

finally:

    pwm.stop()

    cap.release()

    GPIO.cleanup()





#sudo apt-get update

#sudo apt-get install python3-pip libzbar0

#pip3 install opencv-python requests luma.lcd pillow