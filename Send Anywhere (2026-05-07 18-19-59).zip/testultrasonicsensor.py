import RPi.GPIO as GPIO
import time

# Pin Definitions (BCM numbering)
TRIG = 22
ECHO = 27

# GPIO Setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def get_distance():
    # Ensure trigger is low
    GPIO.output(TRIG, False)
    time.sleep(0.5)

    # Send 10us pulse to trigger
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    # Measure the pulse duration on ECHO pin
    pulse_start = time.time()
    pulse_end = time.time()

    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()

    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start

    # Distance = (Time * Speed of Sound) / 2
    # Speed of sound is approx 34300 cm/s
    distance = pulse_duration * 17150
    return round(distance, 2)

try:
    print("Testing Ultrasonic Sensor... Press Ctrl+C to stop.")
    while True:
        dist = get_distance()
        print(f"Measured Distance: {dist} cm")
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\nTest stopped by user.")
finally:
    GPIO.cleanup()